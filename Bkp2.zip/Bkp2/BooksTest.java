package com.demo;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class BooksTest {
	
	public static void main(String[] args) {
		
		List<Books> books = Arrays.asList(
				new Books(1001, "The Psychology of Money", "Morgan Housel", 399, true),
				new Books(1002, "The Alchemist", "Paulo Coelho", 399, false),
				new Books(1003, "The 48 Law of Power", "Robert Greene", 999, true),
				new Books(1004, "Atomic Habits", "James Clear", 899, true),
				new Books(1005, "The One Thing", "Gary Keller", 499, true),
				new Books(1006, "Tuesdays with Morrie", "Mitch Albom", 299, false),
				new Books(1007, "Greatest story for children", "Ruskin Bond", 295, false),
				new Books(1008, "Mindset", "Carel Dweck", 399, true),
				new Books(1009, "Zero to one", "Blake Masters", 599, true),
				new Books(1010, "A Man called Ove", "Fredik Backman", 300, false));
		
		 // Functional interface implementation
		 BookFinder finder = (Integer... ids) -> {
	            List<Books> filtered = books.stream()
	                .filter(book -> Arrays.asList(ids).contains(book.getId()))
	                .filter(book -> book.getPrice() < 500)
	                .collect(Collectors.toList());

	            return filtered.isEmpty() ? Optional.empty() : Optional.of(filtered);
	        };
	        
	     // 1. Display all books
	        finder.display(books);
	        
	     // 2. Filter books with price < 500 and collect
	        List<Books> filteredBooks = books.stream()
	                .filter(b -> b.getPrice() < 500)
	                .collect(Collectors.toList());

	        // 3. Sum the total amount
	        int totalAmount = filteredBooks.stream()
	                .mapToInt(Books::getPrice)
	                .sum();

	        // 4. Check if all filtered books are in stock
	        Optional<Boolean> areAllAvailable = Optional.of(
	                filteredBooks.stream().allMatch(Books::getInStock)
	        );
	        // 5. Final message (No if/else, use Optional and ternary logic)
	        String resultMessage = areAllAvailable
	                .map(available -> available ?
	                        "Total Amount = " + totalAmount + "Purchase Successful" :
	                        "One or more selected books are not available in stock")
	                .orElse(" No matching books found");

	        System.out.println(resultMessage);
	}

}
